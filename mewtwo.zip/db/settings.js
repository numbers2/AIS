



var settings = {
	cookieSecret:'mewtwo',
	db:'jd7e5e30aa189ff_mong_pngj3fi8',
	host:'10.0.31.58'
	// host:'10.6.196.65'
}



module.exports = settings